function mv = moving_average(tsobj, lag)

% tsobj: input variables T by N
% lag: simple moving average with K lags

%clear;clc
%lag = 3; 
%A = [4 8 6 nan -2 -3]';
%tsobj = A;
[T N] = size(tsobj);
res = nan(T,N);
for t = 1:lag-1
 X = tsobj(1:t,:);
 X(any(isnan(X), 2), :) = [];
 res(t,:) = mean(X,1);
 clear X;
end
for t = lag:T
 X = tsobj(t-lag+1:t,:);
 X(any(isnan(X), 2), :) = [];
 res(t,:) = mean(X,1);
 clear X;
end

mv = res;