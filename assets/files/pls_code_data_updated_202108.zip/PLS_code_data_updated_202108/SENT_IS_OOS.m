clear; clc;
%% This code is to predict MKT return with the Sentiment PLS index
 % in- and out-of-sample
 
 % INPUTS:
 % orthogonalize = 1: orthogonalized by 6 macro variables
 %    orthogonalize = 0: do not orthogonalize
 
orthogonalize = 1; 
if orthogonalize == 0
    disp('The results are based on PLS that is not orthogonalized by macro variables')
else
    disp('The results are based on PLS that is orthogonalized by macro variables')
end
 
st_date = 196507;  %start month of BW index
et_date = 202012;  %BW'data ends in 201812; we extend it to 202012
%% Load MKT return
WG    = xlsread('PredictorData2020.xlsx','Monthly','A3:R1802','basic'); 
tt    = find(WG(:,1)>=st_date & WG(:,1)<=et_date);
WG    = WG(tt,:);
Rf    = WG(:,11);
SPvw  = WG(:,17);
logRx = log(1+SPvw)-log(1+Rf); % for in- & oos-forecasting
Rx    = SPvw - Rf; % for portfolio allocation
tdate = WG(:,1);

%% Load sentiment data
BW = xlsread('Investor_Sentiment_RawData_2021_Jiang.xlsx','DATA','A3:R765','basic'); 

%calculate year-to-year macro growth
tt = find(BW(:,1)>=196307&BW(:,1)<=et_date);
BW = BW(tt,:);
T  = length(BW);
gIndpro        = nan(T,1);
gIndpro(13:T)  = BW(13:end,12)./BW(1:end-12,12)-1;
gEmploy        = nan(T,1);
gEmploy(13:T)  = BW(13:end,17)./BW(1:end-12,17)-1;
gConsdur       = nan(T,1);
gConsdur(13:T) = (BW(13:end,13)./BW(1:end-12,13))./(BW(13:end,18)./BW(1:end-12,18))-1;
gConsnon       = nan(T,1);
gConsnon(13:T) = (BW(13:end,14)./BW(1:end-12,14))./(BW(13:end,18)./BW(1:end-12,18))-1;
gConsserv      = nan(T,1);
gConsserv(13:T)= (BW(13:end,15)./BW(1:end-12,15))./(BW(13:end,18)./BW(1:end-12,18))-1;
Macro          = [gIndpro, gEmploy, gConsdur, gConsnon, gConsserv, BW(:,16)];
clear T gIndpro gEmploy gConsdur gConsnon gConsserv;

% As PLS is not scale invariant, so need adjust pdnd and cefd 's signs 
%    to make them proxy for sentiment: high value indicates overpricing 
pdnd = -BW(:,4);
cefd = -BW(:,7);
pdnd = moving_average(pdnd,12);%BW use the sum of the past 12-month values for other variables
cefd = moving_average(cefd,12);%So we apply it to these 2 variables for consistency

if et_date == 202012
    s    = moving_average(BW(:,8),12)./(moving_average(BW(:,8),12)+moving_average(BW(:,9),12));%our collected data
    s(1:end-24) = BW(1:end-24,10);%use BW's data before 201812
else 
    s = BW(:,10); %if et_date<=201812
end
nipo = moving_average(BW(:,6),12);
ripo = moving_average(BW(:,5).*BW(:,6),12)./moving_average(BW(:,6),12); 

%restrict data to be 196507--202012
cefd   = cefd(25:end);
s      = s(25:end);
nipo   = nipo(25:end);
Macro1 = Macro(25:end,:);

%BW use the t-12 value at time t
pdnd   = pdnd(13:end-12);%lagged 12 months
ripo   = ripo(13:end-12);%196407--201912
Macro2 = Macro(13:end-12,:);

%% define target return to predict
target_R = logRx;
T = length(target_R);
%% In-sample forecasting
%Step 0: orthogonalize sentiment proxies
% %orthogonalize one by one
% [~, ~, ~, ~, ~, ~, yhat]=olsnw(cefd,Macro1,1);
% cefd_o = cefd-yhat;
% [~, ~, ~, ~, ~, ~, yhat]=olsnw(s,Macro1,1);
% s_o    = s-yhat;
% [~, ~, ~, ~, ~, ~, yhat]=olsnw(nipo,Macro1,1);
% nipo_o = nipo-yhat;
% [~, ~, ~, ~, ~, ~, yhat]=olsnw(pdnd,Macro2,1);
% pdnd_o = pdnd-yhat;
% [~, ~, ~, ~, ~, ~, yhat]=olsnw(ripo,Macro2,1);
% ripo_o = ripo-yhat;
% BWvar_o = [cefd_o, s_o, nipo_o, pdnd_o, ripo_o];

%orthogonalize by using multivariate regression in matrix
BWvar1 = [cefd, s, nipo]; 
rhv = [ones(T,1), Macro1];
tmp = rhv\BWvar1;
BWvar1_o = BWvar1 - rhv*tmp;
BWvar2 = [pdnd, ripo];
rhv = [ones(T,1), Macro2];
tmp = rhv\BWvar2;
BWvar2_o = BWvar2 - rhv*tmp;
clear rhv tmp;
BWvar_o = [BWvar1_o, BWvar2_o];
BWvar = [BWvar1, BWvar2];

%Step 2: extract the PLS index and predicts
if orthogonalize == 1
    PLS = pls2step(target_R,BWvar_o);
else 
    PLS = pls2step(target_R,BWvar);
end

PLS = -PLS;% PLS is not scale invariant
[b, tstat, ~, ~, R2v, R2vadj, ~]=olsnw(target_R(2:T)*100,PLS(1:T-1),1,1);
%Although using $lag=1 here, we prefer #lags=12 as BW proxies use the past 12-month values
rows ={'intercet'; 't_intercept'; 'beta'; 't_beta'; 'R2(%)'; 'adjR2(%)'};
values = [b(1), tstat(1),b(2),tstat(2), R2v*100, 100*R2vadj]' ;
InSampleResult=table(rows,values)

%%OOS
OS_date = 198507; 
sprintf('OOS is from %d to %d', OS_date, et_date)
t_os    = find(tdate == OS_date);
Ros_SENT_PLS  = NaN*target_R; 
Ros_bar = NaN*target_R; 
for t = t_os:T % t is the forecast month, can use info only up to t-1
    R = target_R(1:t-1);
    %get sentiment data
    bw1   = BWvar1(1:t-1,:);
    mac1  = Macro1(1:t-1,:);
    rhv   = [ones(t-1,1), mac1];
    tmp   = rhv\bw1;
    bw1_o = bw1-rhv*tmp;
    
    bw2   = BWvar2(1:t-1,:);
    mac2  = Macro2(1:t-1,:);
    rhv   = [ones(t-1,1), mac2];
    tmp   = rhv\bw2;
    bw2_o = bw2-rhv*tmp;
    clear bw1 bw2 mac1 mac2 rhv tmp;
    bw_o = [bw1_o, bw2_o];
    
    bw = BWvar(1:t-1,:);
   
    if orthogonalize == 1
       PLS_SENT = pls2step(R,bw_o); 
    else
       PLS_SENT = pls2step(R,bw); 
    end
   %forecast
   rhv = [ones(t-2,1), PLS_SENT(1:t-2)];
   b = rhv\R(2:t-1);
   Ros_SENT_PLS(t)  = [1, PLS_SENT(t-1)]*b;
   Ros_bar(t)       = mean(R);
end

 rvw_OS        = target_R(t_os:T);%realized return 
 Ros_bar       = Ros_bar(t_os:T); %sample mean
 Ros_SENT_PLS  = Ros_SENT_PLS(t_os:T); 
 [R2oos, CSFE] = R2oostest(rvw_OS,Ros_bar,Ros_SENT_PLS);
 rows={'R2os(%)';'p-value';'t-value'};
 values=R2oos([1,2,5])';
 disp('OOS result')
 table(rows,values)
 tos=tdate(t_os:T);
 yr = floor(tos/100);
 mm = tos - yr*100;
 dnum = datenum(yr, mm, 1);
 figure(1)
 plot(dnum,CSFE,'b','linewidth',1)
 recessionplot;
 datetick('keeplimits')
 xlim([datenum(1985,1,1) datenum(floor(et_date/100),12,31)]);
 title('Difference in CSFE')

      
 
        
    
    
    
    
    
 
