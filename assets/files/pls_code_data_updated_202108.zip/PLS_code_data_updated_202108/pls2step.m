function PLS = pls2step(y, x)
% The intercept in the 2nd stage is ZERO bcz x is nomalized
% y: T by 1, is the forecast variable, return
% x: T by K, are the individual proxies of sentiment

x = zscore(x);
%y = zscore(y); %no need include a if using this one
T = size(x,1);

%regress x_t = a + by_t+1 + u_t
rh = [y(2:end) ones(T-1,1)];
bv = rh\x(1:end-1,:);
b  = bv(1,:)';
 
%regress x_t on b: x_t = PLS_t*b
PLS = nan(T,1);
for t=1:T
    lh = x(t,:)';
    rh = b;
    %[bv,sebv,R2v,R2vadj,v,F] = olsWhite(lh, rh)   ;
    [b_xs, ~, ~, ~, ~, ~, ~]=olsnw(lh,rh,0,0);
    PLS(t,1)=b_xs(1);
end

PLS = zscore(PLS);
 