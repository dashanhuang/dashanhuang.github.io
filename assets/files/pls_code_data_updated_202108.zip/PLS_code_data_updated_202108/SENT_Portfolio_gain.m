clear; clc;
%% This code is to calculate portfolio gain by using the PLS sentiment index
 % in real time
 % INPUTS:
 % orthogonalize = 1: orthogonalized by 6 macro variables
 %     orthogonalize = 0: do not orthogonalize
 % gma=5: risk aversion
 % OUTPUTS:
 % utility gain= CER(with prediction) - CER(with sample mean)

 
orthogonalize = 0;
if orthogonalize == 0
    disp('The results are based on PLS that is not orthogonalized by macro variables')
else
    disp('The results are based on PLS that is orthogonalized by macro variables')
end

st_date = 196507;  %start month of BW index
et_date = 202012;  %BW'data ends in 201812; we extend it to 202012
%% Load MKT return
WG    = xlsread('PredictorData2020.xlsx','Monthly','A3:R1802','basic'); 
tt    = find(WG(:,1)>=st_date & WG(:,1)<=et_date);
WG    = WG(tt,:);
Rf    = WG(:,11);
SPvw  = WG(:,17);
logRx = log(1+SPvw)-log(1+Rf); % for in- & oos-forecasting
Rx    = SPvw - Rf; % for portfolio allocation
Svar  = nan*Rx;    % determine portfolio wegith
for t = 60:length(Rx)
    Svar(t) = var(Rx(t-59:t));
end
tdate = WG(:,1);

%% Load sentiment data
BW = xlsread('Investor_Sentiment_RawData_2021_Jiang.xlsx','DATA','A3:R765','basic'); 

%calculate year-to-year macro growth
tt = find(BW(:,1)>=196307&BW(:,1)<=et_date);
BW = BW(tt,:);
T  = length(BW);
gIndpro        = nan(T,1);
gIndpro(13:T)  = BW(13:end,12)./BW(1:end-12,12)-1;
gEmploy        = nan(T,1);
gEmploy(13:T)  = BW(13:end,17)./BW(1:end-12,17)-1;
gConsdur       = nan(T,1);
gConsdur(13:T) = (BW(13:end,13)./BW(1:end-12,13))./(BW(13:end,18)./BW(1:end-12,18))-1;
gConsnon       = nan(T,1);
gConsnon(13:T) = (BW(13:end,14)./BW(1:end-12,14))./(BW(13:end,18)./BW(1:end-12,18))-1;
gConsserv      = nan(T,1);
gConsserv(13:T)= (BW(13:end,15)./BW(1:end-12,15))./(BW(13:end,18)./BW(1:end-12,18))-1;
Macro          = [gIndpro, gEmploy, gConsdur, gConsnon, gConsserv, BW(:,16)];
clear T gIndpro gEmploy gConsdur gConsnon gConsserv;

pdnd = -BW(:,4);%to make it a proxy for sentiment
cefd = -BW(:,7);%so that high value indicates overpricing
pdnd = moving_average(pdnd,12);%BW use the past 12-month values for other variables
cefd = moving_average(cefd,12);%So we apply it to these 2 variables for consistency

if et_date == 202012
    s = moving_average(BW(:,8),12)./(moving_average(BW(:,8),12)+moving_average(BW(:,9),12));%our collected data
    s(1:end-24) = BW(1:end-24,10);%use BW's data before 201812
else 
    s = BW(:,10); %if et_date<=201812
end
nipo = moving_average(BW(:,6),12);
ripo = moving_average(BW(:,5).*BW(:,6),12)./moving_average(BW(:,6),12); 

%restrict data to be 196507--202012
cefd   = cefd(25:end);
s      = s(25:end);
nipo   = nipo(25:end);
BWvar1 = [cefd, s, nipo]; 
Macro1 = Macro(25:end,:);

%BW use the t-12 value at time t
pdnd   = pdnd(13:end-12);%lagged 12 months
ripo   = ripo(13:end-12);%196407--201912
BWvar2 = [pdnd, ripo];
Macro2 = Macro(13:end-12,:);
BWvar = [BWvar1, BWvar2];

%% define target return to predict
target_R = Rx; %arithmetic return
T        = length(target_R);
gma      = 3; %risk aversion 

%% Portfolio selection in real time
OS_date   = 198507; 
sprintf('investing from %d to %d', OS_date, et_date)
t_os      = find(tdate == OS_date);
Ros_SENT_PLS  = NaN*target_R; 
Ros_bar   = NaN*target_R; 
for t = t_os:T % t is the forecast month, can use info only up to t-1
    R     = target_R(1:t-1);
    %get sentiment data
    bw1   = BWvar1(1:t-1,:);
    mac1  = Macro1(1:t-1,:);
    rhv   = [ones(t-1,1), mac1];
    tmp   = rhv\bw1;
    bw1_o = bw1-rhv*tmp;
    
    bw2   = BWvar2(1:t-1,:);
    mac2  = Macro2(1:t-1,:);
    rhv   = [ones(t-1,1), mac2];
    tmp   = rhv\bw2;
    bw2_o = bw2-rhv*tmp;
    clear bw1 bw2 mac1 mac2 rhv tmp;
    bw_o = [bw1_o, bw2_o];%orthogonalized by macro variables
    
    bw = BWvar(1:t-1,:);%without orthogonalized by macro
    
    if orthogonalize == 1
       PLS_SENT = pls2step(R,bw_o); 
    else
       PLS_SENT = pls2step(R,bw); 
    end

   %forecast
   rhv              = [ones(t-2,1), PLS_SENT(1:t-2)];
   b                = rhv\R(2:t-1);
   Ros_SENT_PLS(t)  = [1, PLS_SENT(t-1)]*b;
   Ros_SENT_PLSr(t) = max([1, PLS_SENT(t-1)]*b, 0);
   Ros_bar(t)       = mean(R);
end

 Ractual   = target_R(t_os:T); 
 Ros_bar   = Ros_bar(t_os:T);     %forecasted at t-1
 Ros_hat   = Ros_SENT_PLS(t_os:T);%forecasted at t-1 
 Rvar      = Svar(t_os-1:T-1);    %calculated at t-1
 Rf        = Rf(t_os:T);
 w_port    = (1/gma)*Ros_hat./Rvar;   %without constraint on w
 w_low     = 0;
 w_up      = 1.5;
 w_port    = min(max(w_low, w_port),w_up); %w in [0, 1.5]
 w_sample  = (1/gma)*Ros_bar./Rvar;
 w_sample  = min(max(w_low,w_sample),w_up);
 Rport     = Rf + w_port.*Ractual;
 Rsample   = Rf + w_sample.*Ractual;
 
 CER       = mean(Rport)-0.5*gma*var(Rport);
 CERsample = mean(Rsample)-0.5*gma*var(Rsample);
 sprintf('Utility gain with w in [%.1f, %.1f] and gamma=%d is',w_low, w_up, gma)
 dCER      = (CER-CERsample)*1200
  
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
    
    
 
