%% Table 3 Panel B Wild bootstrap %%

clear;clc
addpath 'C:\Users\wly\Desktop\TSM_Codes';

Return = xlsread('Return.xlsx','Return','A2:F19634','basic');
% Return = [1.year_month, 2.excess return, 3.volatility, 4.risk free, 5.NBER, 6.ID]

Ns = 1; Ne = 55; 
Return = Return(Return(:,1)>=198501,:);
Rs = Return(:,2);
rf = Return(:,4)+1;
exVol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);                    % generate 1-12 month cumulative returns
Rcumvol = Rcum(2:end,:)./exVol(1:end-1);
Rcumvol = [nan(1,12); Rcumvol];
Rcumvol = [Rcumvol, Return(:,6)];
% Drop first 12 observations in case of NaN %
for ss = Ns:Ne
      aa = find(Rcumvol(:,13)==ss);
      Rcumvol(aa(1):aa(12),:) = [];
      bb = find(Return(:,6)==ss);
      Return(bb(1):bb(12),:) = [];
end

z0 = Return(:, [1, 2, 4, 6, 3]);                       %            1       2       3   4    5         6-17
z0 = [z0, Rcumvol(:,1:12)];                           %  z0 =  [ym, xret, rf, id, vol, xcum/vol]

% Run predictive pool regression %
res = [];
for h = 1:12
    yy = [];
    for n = Ns:Ne 
      tt = find(z0(:,4) == n);
      a = z0(tt,:);                                                 % [ym, xret, rf, id, vol, xcum/vol]                                                                           
      yy = [yy; a(2:end,6), a(1:end-1,5+h), a(2:end,[1, 4])];    % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res = [res; b(1, [1, 3]), b(2, [1, 3])];        % res = [b, b_tstat, cons, cons_tstat]
end
pool_alpha = res(:,3)'; pool_beta = res(:,1)';

% Generate epsilonhat and yhat %
Reshat = []; Pedhat = [];
for h = 1:12
    Reshat_n = []; Pedhat_n = [];
    for n = Ns:Ne
        z_n = z0(z0(:,4)==n,:);                           %             1     2       3   4    5     6-17
        Exhat = nan(length(z_n),2);                 % z0 =  [ym, xret, rf, id, vol, xcum/vol]         
        for i = 1:length(z_n)-1                                                                                   
            Exhat(i+1,1) = [z_n(i,5+h), 1]*[pool_beta(h), pool_alpha(h)]';    % y_{h,hat} = pool_alpha + pool_beta*y_{h,t-1}                  
        end
        for i = 2:length(z_n)
            Exhat(i,2) = z_n(i,6) - Exhat(i,1);     % epsilon_{h,hat} = y_{t,h} - y_{h,hat}                                            
        end
        Pedhat_n = [Pedhat_n; Exhat(:,1)];  
        Reshat_n = [Reshat_n; Exhat(:,2)];                      
    end
    Pedhat = [Pedhat, Pedhat_n];
    Reshat = [Reshat, Reshat_n];
end
Pedhat = [Pedhat, z0(:,4)];
Reshat = [Reshat, z0(:,4)];

for s = Ns:Ne
    line1 = find(Reshat(:,13)==s);
    Reshat(line1(1),:) = [];
    line2 = find(Pedhat(:,13)==s);
    Pedhat(line2(1),:) = [];
    line3 = find(z0(:,4)==s);
    z0(line3(1),:) = [];
end

% Bootstrap for 1000 times %
B = 1000; 
beta_all = nan(B,12); tstat_all = nan(B,12);
for i = 1:B
    tic
    y_boot_all = []; 
    for s = Ns:Ne
          rng(s*i);                                                  % set seed
          tY = z0(z0(:,4)==s,1);                           % z0 = [ym, xret, rf, id, vol, xcum/vol]    
          T = length(tY);
          Pedhat_s = Pedhat(Pedhat(:,13)==s,:);  % matrix of y_hat for h = 1-12
          Reshat_s = Reshat(Reshat(:,13)==s,:);   % matrix of epsilon_hat for h = 1-12

          rand_b = [rand(T+100,1), rand(T+100,1), rand(T+100,1), rand(T+100,1), ...
              rand(T+100,1), rand(T+100,1), rand(T+100,1), rand(T+100,1), ...
              rand(T+100,1), rand(T+100,1), rand(T+100,1), rand(T+100,1)];
          
          y_boot = nan(T,12);
          % Construct pseudo sample path %
          for t = 1:T
            vt = ((rand_b(t+100,:)>=0.5)*(1) + (rand_b(t+100,:)<0.5)*(-1));
            y_boot(t,:) = Pedhat_s(t,1:12) + Reshat_s(t,1:12).*vt;   % y*_{h,t} = pool_alpha + pool_beta*y{h,t-1} + epsilon_{h,hat}*v{h,t}                     
          end
          y_boot_all = [y_boot_all; y_boot];
   end
   z_y = [z0(:,1), z0(:,4), y_boot_all];
     
   res_i = []; res_sign_i = [];
  for h = 1:12
       yy = []; 
       for n = Ns:Ne 
       ta = find(z_y(:,2) == n);                          %              1         2         3-14       
       a = z_y(ta,:);                                             % z_y =  [ym      ID       boot-y]  
            
       tb = find(z0(:,4)==n);                              %             1          2          3         4         5         6                                         
       b = z0(tb,:);                                               % z0 =  [ym       xret      rf        ID     vol   xcum/vol]
       yy = [yy; a(2:end,2+h), b(1:end-1,5+h), a(2:end,[1, 2])];  %  original independent variables and bootstrapped  dependent variables 
       end
       b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
       res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
   end
   beta_all(i,:) = res_i(:,1)';
   tstat_all(i,:) = res_i(:,2)';
   toc
   i
end

% Calculate 97.5% of boostrapped t-stat %
boot_tstat = []; 
for j = 1:12
   wild_j = tstat_all(:,j);
   boot_tstat = [boot_tstat; prctile(wild_j, 97.5)];
end

fprintf('\n\nTable 3 Panel B Wild bootstrapped t-stat \n\n')
boot_tstat

