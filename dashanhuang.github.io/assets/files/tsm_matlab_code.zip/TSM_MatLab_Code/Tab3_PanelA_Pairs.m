%% Table 3 Panel A Pairs bootstrap %%

clear;clc
addpath 'C:\Users\wly\Desktop\TSM_Codes';

Return = xlsread('Return.xlsx','Return','A2:F19634','basic');
% Return = [1.year_month, 2.excess return, 3.volatility, 4.risk free, 5.NBER, 6.ID]

Ns = 1; Ne = 55; 
Return = Return(Return(:,1)>=198501,:);
Rs = Return(:,2);
exVol = Return(:,3);
Retvol = Rs(2:end)./exVol(1:end-1);
Return = [Return, [nan; Retvol]];
% Drop first 12 observations in case of NaN %
for ss = Ns:Ne
    bb = find(Return(:,6)==ss);
    Return(bb(1):bb(12),:) = [];
end
% Align lagged vol-scaled returns into one matrix %
lagRetvol1 = [nan; Return(1:end-1,7)];
lagRetvol2 = [nan(2,1); Return(1:end-2,7)];
lagRetvol3 = [nan(3,1); Return(1:end-3,7)];
lagRetvol4 = [nan(4,1); Return(1:end-4,7)];
lagRetvol5 = [nan(5,1); Return(1:end-5,7)];
lagRetvol6 = [nan(6,1); Return(1:end-6,7)];
lagRetvol7 = [nan(7,1); Return(1:end-7,7)];
lagRetvol8 = [nan(8,1); Return(1:end-8,7)];
lagRetvol9 = [nan(9,1); Return(1:end-9,7)];
lagRetvol10 = [nan(10,1); Return(1:end-10,7)];
lagRetvol11 = [nan(11,1); Return(1:end-11,7)];
lagRetvol12 = [nan(12,1); Return(1:end-12,7)];
lagRetvol = [Return(:,7), lagRetvol1, lagRetvol2, lagRetvol3, lagRetvol4, lagRetvol5,...
    lagRetvol6, lagRetvol7, lagRetvol8, lagRetvol9, lagRetvol10, lagRetvol11, lagRetvol12];
                                                                           
z0 = Return(:, [1, 6]);                                     %            1     2         3         4-15
z0 = [z0, lagRetvol];                                       % z0 =  [ym, id, Retvol, lagRetvol] 

% Bootstrap for 1000 times %
B = 1000; 
beta_all = nan(B,12); tstat_all = nan(B,12);
for i = 1:B
    tic
    Boot_ret1 = []; Boot_ret2 = []; Boot_ret3 = []; Boot_ret4 = []; 
    Boot_ret5 = []; Boot_ret6 = []; Boot_ret7 = []; Boot_ret8 = []; 
    Boot_ret9 = []; Boot_ret10 = []; Boot_ret11 = []; Boot_ret12 = []; 
    for s = Ns:Ne
        rng(s*i);                                                    % set seed              
        Retvol1 = z0(z0(:,2)==s,[1, 2, 3, 4]);  % z0 = [ym, id, Retvol, lag1Retvol] 
        Retvol1 = Retvol1(2:end,:);
        T = length(Retvol1);
        resample1 = Retvol1(ceil(T*rand(T+100,1)),:);      % randomly draw y and x together
        Boot_ret1 = [Boot_ret1; resample1(101:end,:)];
        
        Retvol2 = z0(z0(:,2)==s,[1, 2, 3, 5]);  % z0 = [ym, id, Retvol, lag2Retvol] 
        Retvol2 = Retvol2(3:end,:);
        T = length(Retvol2);
        resample2 = Retvol2(ceil(T*rand(T+100,1)),:);      
        Boot_ret2 = [Boot_ret2; resample2(101:end,:)];
        
        Retvol3 = z0(z0(:,2)==s,[1, 2, 3, 6]);  % z0 = [ym, id, Retvol, lag3Retvol] 
        Retvol3 = Retvol3(4:end,:);
        T = length(Retvol3);
        resample3 = Retvol3(ceil(T*rand(T+100,1)),:);      
        Boot_ret3 = [Boot_ret3; resample3(101:end,:)];
        
        Retvol4 = z0(z0(:,2)==s,[1, 2, 3, 7]);  % z0 = [ym, id, Retvol, lag4Retvol] 
        Retvol4 = Retvol4(5:end,:);
        T = length(Retvol4);
        resample4 = Retvol4(ceil(T*rand(T+100,1)),:);      
        Boot_ret4 = [Boot_ret4; resample4(101:end,:)];
        
        Retvol5 = z0(z0(:,2)==s,[1, 2, 3, 8]);  % z0 = [ym, id, Retvol, lag5Retvol] 
        Retvol5 = Retvol5(6:end,:);
        T = length(Retvol5);
        resample5 = Retvol5(ceil(T*rand(T+100,1)),:);      
        Boot_ret5 = [Boot_ret5; resample5(101:end,:)];
        
        Retvol6 = z0(z0(:,2)==s,[1, 2, 3, 9]);  % z0 = [ym, id, Retvol, lag6Retvol] 
        Retvol6 = Retvol6(7:end,:);
        T = length(Retvol6);
        resample6 = Retvol6(ceil(T*rand(T+100,1)),:);      
        Boot_ret6 = [Boot_ret6; resample6(101:end,:)];
        
        Retvol7 = z0(z0(:,2)==s,[1, 2, 3, 10]);% z0 = [ym, id, Retvol, lag7Retvol] 
        Retvol7 = Retvol7(8:end,:);
        T = length(Retvol7);
        resample7 = Retvol7(ceil(T*rand(T+100,1)),:);      
        Boot_ret7 = [Boot_ret7; resample7(101:end,:)];
        
        Retvol8 = z0(z0(:,2)==s,[1, 2, 3, 11]);% z0 = [ym, id, Retvol, lag8Retvol] 
        Retvol8 = Retvol8(9:end,:);
        T = length(Retvol8);
        resample8 = Retvol8(ceil(T*rand(T+100,1)),:);      
        Boot_ret8 = [Boot_ret8; resample8(101:end,:)];
        
        Retvol9 = z0(z0(:,2)==s,[1, 2, 3, 12]);% z0 = [ym, id, Retvol, lag9Retvol] 
        Retvol9 = Retvol9(10:end,:);
        T = length(Retvol9);
        resample9 = Retvol9(ceil(T*rand(T+100,1)),:);      
        Boot_ret9 = [Boot_ret9; resample9(101:end,:)];
        
        Retvol10 = z0(z0(:,2)==s,[1, 2, 3, 13]);% z0 = [ym, id, Retvol, lag10Retvol] 
        Retvol10 = Retvol10(11:end,:);
        T = length(Retvol10);
        resample10 = Retvol10(ceil(T*rand(T+100,1)),:);      
        Boot_ret10 = [Boot_ret10; resample10(101:end,:)];
        
        Retvol11 = z0(z0(:,2)==s,[1, 2, 3, 14]);% z0 = [ym, id, Retvol, lag11Retvol] 
        Retvol11 = Retvol11(12:end,:);
        T = length(Retvol11);
        resample11 = Retvol11(ceil(T*rand(T+100,1)),:);      
        Boot_ret11 = [Boot_ret11; resample11(101:end,:)];
        
        Retvol12 = z0(z0(:,2)==s,[1, 2, 3, 15]);% z0 = [ym, id, Retvol, lag12Retvol] 
        Retvol12 = Retvol12(13:end,:);
        T = length(Retvol12);
        resample12 = Retvol12(ceil(T*rand(T+100,1)),:);     
        Boot_ret12 = [Boot_ret12; resample12(101:end,:)];
    end
    res_i = []; 
    % 1 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret1(:,2) == n);             %          1         2         3                 4
        a = Boot_ret1(tt,:);                                % a = [ym      ID      Retvol  lag-Retvol]
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];

    % 2 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret2(:,2) == n);                            
        a = Boot_ret2(tt,:);                                           
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 3 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret3(:,2) == n);                         
        a = Boot_ret3(tt,:);                                          
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 4 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret4(:,2) == n);                            
        a = Boot_ret4(tt,:);                                           
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 5 month %
    yy = []; 
    for n = Ns:Ne
        tt = find(Boot_ret5(:,2) == n);                        
        a = Boot_ret5(tt,:);                                           
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 6 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret6(:,2) == n);                        
        a = Boot_ret6(tt,:);                                          
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 7 month %
    yy = []; 
    for n = Ns:Ne
        tt = find(Boot_ret7(:,2) == n);                        
        a = Boot_ret7(tt,:);                                        
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 8 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret8(:,2) == n);                             
        a = Boot_ret8(tt,:);                                           
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 9 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret9(:,2) == n);                        
        a = Boot_ret9(tt,:);                                           
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 10 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret10(:,2) == n);                        
        a = Boot_ret10(tt,:);                                         
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    % 11 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret11(:,2) == n);                        
        a = Boot_ret11(tt,:);                                          
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
     
    % 12 month %
    yy = []; 
    for n = Ns:Ne 
        tt = find(Boot_ret12(:,2) == n);                           
        a = Boot_ret12(tt,:);                                          
        yy = [yy; a(:,3), a(:,4), a(:,[1, 2])];       % yy = [y, x,  ym, ID]; 
    end
    b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
    res_i = [res_i; b(1, [1, 3]), b(2, [1, 3])];
    
    beta_all(i,:) = res_i(:,1)';
    tstat_all(i,:) = res_i(:,2)';
    toc
    i
end

% Calculate 97.5% of boostrapped t-stat %
boot_tstat = []; 
for j = 1:12
   pairs_j = tstat_all(:,j);
   boot_tstat = [boot_tstat; prctile(pairs_j, 97.5)];
end

fprintf('\n\nTable 3 Panel A Pairs bootstrapped t-stat \n\n')
boot_tstat
