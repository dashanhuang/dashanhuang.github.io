%% Table 9 Panel A Fama-French four-factor model %%

clear;clc
addpath 'C:\Users\wly\Desktop\TSM_Codes';

Return = xlsread('Return.xlsx','Return','A2:F19634','basic');
% Return = [1.year_month, 2.excess return, 3.volatility, 4.risk free, 5.NBER, 6.ID]

MSCI_FFG = xlsread('Factors.xlsx','FF4','A2:E373','basic');

Ns = 1; Ne = 55; 
Ret = Return(Return(:,1)>=198501,:);
rf = Ret(:,4)+1;
R = Ret(:,2)+rf;
T = length(R);
R12 = (R(1:T-11)).*(R(2:T-10)).*(R(3:T-9)).*(R(4:T-8)).*(R(5:T-7)).*(R(6:T-6)).*...
     (R(7:T-5)).*(R(8:T-4)).*(R(9:T-3)).*(R(10:T-2)).*(R(11:T-1)).*(R(12:T));
Rf = (rf(1:T-11)).*(rf(2:T-10)).*(rf(3:T-9)).*(rf(4:T-8)).*(rf(5:T-7)).*(rf(6:T-6)).*...
     (rf(7:T-5)).*(rf(8:T-4)).*(rf(9:T-3)).*(rf(10:T-2)).*(rf(11:T-1)).*(rf(12:T));
R12x = [nan(11,1); R12-Rf];                                    

Ret = [Ret, R12x];
% Generate historical mean %
Ret_mean = [];
for i = Ns:Ne
  Ret_i = Ret(Ret(:,6)==i,2);  
  T = length(Ret_i);
  mean_i = nan(T,1);
  for t = 1:T
     mean_i(t) = mean(Ret_i(1:t));
  end
  Ret_mean = [Ret_mean; mean_i];
end
Ret = [Ret, Ret_mean];
% Drop the first 11 observations %
for n = Ns:Ne
    aa = find(Ret(:,6)==n);
    Ret(aa(1):aa(11),:) = [];
end
% Define the longest time period %
tdate = Ret(Ret(:,6)==3,1);
% Calculate long/short returns for each strategies %
[tsm_long, anntsm_long, Ret_tsm_long] = Func_TSM_long(Ret, Ne, tdate);
tsm_long = [tdate(2:end), tsm_long];

[tsm_short, anntsm_short, Ret_tsm_short] = Func_TSM_short(Ret, Ne, tdate);
tsm_short = [tdate(2:end), tsm_short];

[tsh_long, anntsh_long, Ret_tsh_long] = Func_TSH_long(Ret, Ne, tdate);
tsh_long = [tdate(2:end), tsh_long];

[tsh_short, anntsh_short, Ret_tsh_short] = Func_TSH_short(Ret, Ne, tdate);
tsh_short = [tdate(2:end), tsh_short];

%% Time-series momentum strategy %%
MSCI_FFG = MSCI_FFG(MSCI_FFG(:,1)>=tsm_long(1,1)&MSCI_FFG(:,1)<=tsm_long(end,1),:);
y = tsm_long(:,2);
x = [ones(size(y)), MSCI_FFG(:,2:end)];
[beta, sebv, R2] = olsgmm(y,x,12,1);
loading1 = [beta'; beta'./sebv'];
loading1(1,1) = loading1(1,1)*100;
fprintf('\n\nTSM long \n\n')
mRet = mean(y)*100;
cons = ones(size(y));
[beta, tstat] = olsnw(y, cons,0);
Mean = [mRet;tstat]
loading1
R2 = R2*100
clear y x

y = tsm_short(:,2);
x = [ones(size(y)), MSCI_FFG(:,2:end)];
[beta, sebv, R2] = olsgmm(y,x,12,1);
loading2 = [beta'; beta'./sebv'];
loading2(1,1) = loading2(1,1)*100;
fprintf('\n\nTSM short \n\n')
mRet = mean(y)*100;
cons = ones(size(y));
[beta, tstat] = olsnw(y, cons,0);
Mean = [mRet;tstat]
loading2
R2 = R2*100
clear y x

y = tsm_long(:,2) - tsm_short(:,2);
x = [ones(size(y)), MSCI_FFG(:,2:end)];
[beta, sebv, R2] = olsgmm(y,x,12,1);
loading3 = [beta'; beta'./sebv'];
loading3(1,1) = loading3(1,1)*100;
tsm_hat = x(:,2:end)*beta(2:end);
res_tsm = y - tsm_hat;
fprintf('\n\nTSM long-short \n\n')
mRet = mean(y)*100;
cons = ones(size(y));
[beta, tstat] = olsnw(y, cons,0);
Mean = [mRet;tstat]
loading3
R2 = R2*100
clear y x

%% Time-series historical strategy %%
y = tsh_long(:,2);
x = [ones(size(y)), MSCI_FFG(:,2:end)];
[beta, sebv, R2] = olsgmm(y,x,12,1);
loading5 = [beta'; beta'./sebv'];
loading5(1,1) = loading5(1,1)*100;
fprintf('\n\nTSH long \n\n')
mRet = mean(y)*100;
cons = ones(size(y));
[beta, tstat] = olsnw(y, cons,0);
Mean = [mRet;tstat]
loading5
R2 = R2*100
clear y x

y = tsh_short(:,2);
x = [ones(size(y)), MSCI_FFG(:,2:end)];
[beta, sebv, R2] = olsgmm(y,x,12,1);
loading6 = [beta'; beta'./sebv'];
loading6(1,1) = loading6(1,1)*100;
fprintf('\n\nTSH short \n\n')
mRet = mean(y)*100;
cons = ones(size(y));
[beta, tstat] = olsnw(y, cons,0);
Mean = [mRet;tstat]
loading6
R2 = R2*100
clear y x

y = tsh_long(:,2) - tsh_short(:,2);
x = [ones(size(y)), MSCI_FFG(:,2:end)];
[beta, sebv, R2] = olsgmm(y,x,12,1);
loading7 = [beta'; beta'./sebv'];
loading7(1,1) = loading7(1,1)*100;
tsh_hat = x(:,2:end)*beta(2:end);
res_tsh = y - tsh_hat;
fprintf('\n\nTSH long-short \n\n')
mRet = mean(y)*100;
cons = ones(size(y));
[beta, tstat] = olsnw(y, cons,0);
Mean = [mRet;tstat]
loading7
R2 = R2*100
clear y x

%% Compare mean and alpha difference %%
fprintf('\n\nTSM Vs TSH Mean Diff \n\n')
[h1, p1] = ttest(tsm_long(:,2)-tsm_short(:,2), tsh_long(:,2)-tsh_short(:,2));
p1
fprintf('\n\nTSM Vs TSH Alpha Diff \n\n')
[h2, p2] = ttest(res_tsm, res_tsh);
p2











