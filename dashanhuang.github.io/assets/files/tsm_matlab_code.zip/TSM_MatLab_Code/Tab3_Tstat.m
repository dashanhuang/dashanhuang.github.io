%% Table 3 Panel A T-stat %%

clear;clc
addpath 'C:\Users\wly\Desktop\TSM_Codes';

Return = xlsread('Return.xlsx','Return','A2:F19634','basic');
% Return = [1.year_month, 2.excess return, 3.volatility, 4.risk free, 5.NBER, 6.ID]

Ns = 1; Ne = 55;
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);
Return = Return(Return(:,1)>=198501,:);

% Generate xret/vol %
z = [nan; Return(2:end,2)./Return(1:end-1,3)];
z = [Return, z];
% Drop first 12 observations in case of NaN %
for s = Ns:Ne
    line1 = find(z(:,6)==s);
    z(line1(1):line1(12),:) = []; 
end
z = z(:, [1, 6, 7]);                                              % [ym, id, xret/vol]

res = []; 
for h = 1:12
    yy = [];
    for n = Ns:Ne 
        tt = find(z(:,2) == n);
        a = z(tt,:); 
        yy = [yy; a(h+1:end,3), a(1:end-h,3), a(h+1:end,[1, 2])];   % yy = [y, x,  ym, id]; 
    end
  b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
  res = [res; b(1, [1, 3]), b(2, [1, 3])];
end

Result1 = res(:,2);
fprintf('\n\nPanel A t-stat \n\n')
Result1

%% Table 3 Panel B T-stat %%

clear;
addpath 'C:\Users\wly\Desktop\TSM_Codes';

Return = xlsread('Return.xlsx','Return','A2:F19634','basic');
% Return = [1.year_month, 2.excess return, 3.volatility, 4.risk free, 5.NBER, 6.ID]

Ns = 1; Ne = 55;
Return = Return(Return(:,6)>=Ns & Return(:,6)<=Ne,:);
Return = Return(Return(:,1)>=198501,:);
Rs = Return(:,2);
rf = Return(:,4)+1;
Exvol = Return(:,3);
Rcum = Func_GenCum(rf, Rs);

Rcumvol = Rcum(2:end,:)./Exvol(1:end-1);
z = [nan(1,12); Rcumvol];                             %           1-12                13     14
z = [z, Return(:,1), Return(:,6)];                   % z = [xcum/exvol    ym      id]
% Drop first 12 observations in case of NaN %
for n = Ns:Ne
    line1 = find(z(:,14)==n);
    z(line1(1):line1(12),:) = [];
end

res = []; 
for h = 1:12
   yy = [];
   for n = Ns:Ne 
       tt = find(z(:,14) == n);                             %            1 -12             13       14   
       a = z(tt,:);                                                  %  a = [xcum/exvol    ym      id]
       yy = [yy; a(2:end,1), a(1:end-1,h), a(2:end,[13, 14])];       %  yy = [y, x,  ym, id]; 
   end
b = clusterreg(yy(:,1), [yy(:,2), ones(size(yy(:,2)))], yy(:,3));
res = [res; b(1, [1 3]), b(2, [1 3])];
end

Result2 = res(:,2);
fprintf('\n\nPanel B t-stat \n\n')
Result2
