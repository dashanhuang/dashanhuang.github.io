import pandas as pd
import numpy as np
import statsmodels.formula.api as smf

# =============================================================================
# Objective: 
# generate the wild bootstrap t-values for
# predictive regression with lagged volatiliaty scaled excess return
# =============================================================================

# =============================================================================
# create the lagged volatiliaty scaled excess returns
# =============================================================================

ret=pd.read_excel('Return.xlsx','Return')
ret=ret[ret['YM']>=198501]# make sure all returns are after 198501

ret_summary=pd.DataFrame()
for i in range(1,56):
    ret_sub=ret[ret['ID']==i]    
    #get the scaled excess return
    ret_sub['ExRetVol']=ret_sub['ExRet']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetVol_f1']=ret_sub['ExRetVol'].shift(-1)
    ret_sub['ExRetVol_l0']=ret_sub['ExRetVol'].shift(0)
    ret_sub['ExRetVol_l1']=ret_sub['ExRetVol'].shift(1)
    ret_sub['ExRetVol_l2']=ret_sub['ExRetVol'].shift(2)
    ret_sub['ExRetVol_l3']=ret_sub['ExRetVol'].shift(3)
    ret_sub['ExRetVol_l4']=ret_sub['ExRetVol'].shift(4)
    ret_sub['ExRetVol_l5']=ret_sub['ExRetVol'].shift(5)
    ret_sub['ExRetVol_l6']=ret_sub['ExRetVol'].shift(6)
    ret_sub['ExRetVol_l7']=ret_sub['ExRetVol'].shift(7)
    ret_sub['ExRetVol_l8']=ret_sub['ExRetVol'].shift(8)
    ret_sub['ExRetVol_l9']=ret_sub['ExRetVol'].shift(9)
    ret_sub['ExRetVol_l10']=ret_sub['ExRetVol'].shift(10)
    ret_sub['ExRetVol_l11']=ret_sub['ExRetVol'].shift(11)

    ret_summary=pd.concat([ret_summary,ret_sub.iloc[12:]])#drop the first 12 variables

# =============================================================================
# prepare a table to fitted value and the residual value of the panel regression
# =============================================================================
    
fitted_residual=pd.DataFrame()
#keep fitted, residual, explanatory 

for i in range(0,12):
    new_name='ExRetVol_l'+str(i)
    regression=ret_summary[['YM','ExRetVol_f1',new_name]].dropna()
    form="ExRetVol_f1 ~ ExRetVol_l"+str(i)
    result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
    fitted_residual['fitted_Lag'+str(i+1)]=result.fittedvalues
    fitted_residual['residual_Lag'+str(i+1)]=result.resid
    fitted_residual[new_name]=regression[new_name]

fitted_residual[['YM','ExRetVol_f1']]=regression[['YM','ExRetVol_f1']]

# =============================================================================
# run the wild bootstrap regression
# =============================================================================

size=len(fitted_residual)
np.random.seed(10)

tLag_Wild=np.empty((1000,12))

for n in range(0,1000):
    vera=np.random.uniform(0,1,size)
    vera=np.where(vera>=0.5,1,-1)
    fitted_residual['vera']=vera
    for i in range(1,13):
        fitted_residual['star_Lag'+str(i)]=fitted_residual['fitted_Lag'+str(i)]+fitted_residual['vera']*fitted_residual['residual_Lag'+str(i)]
        
        regression=fitted_residual[['YM','star_Lag'+str(i),'ExRetVol_l'+str(i-1)]].dropna()
        form="star_Lag"+str(i)+" ~ ExRetVol_l"+str(i-1)
        result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
        tLag_Wild[n,i-1]=result.tvalues[1]
    print(n)
        
Table3_PanelAWild=pd.DataFrame(columns=['Lag'],index=np.arange(1,13))

for i in range(1,13):
    Table3_PanelAWild.loc[[i],['Lag']]=np.percentile(tLag_Wild[:,i-1],97.5)

pd.DataFrame.to_csv(Table3_PanelAWild,'Table3_PanelAWild.csv')