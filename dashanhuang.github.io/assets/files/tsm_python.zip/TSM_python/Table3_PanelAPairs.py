import pandas as pd
import numpy as np
import statsmodels.formula.api as smf

# =============================================================================
# Objective: 
# generate the pairs bootstrap t-values for Table3 Panel A 
# =============================================================================

# =============================================================================
# create the lagged volatiliaty scaled excess returns
# =============================================================================

ret=pd.read_excel('Return.xlsx','Return')
ret=ret[ret['YM']>=198501]# make sure all returns are after 198501

ret_summary=pd.DataFrame()
for i in range(1,56):
    ret_sub=ret[ret['ID']==i]    
    #get the scaled excess return
    ret_sub['ExRetVol']=ret_sub['ExRet']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetVol_f1']=ret_sub['ExRetVol'].shift(-1)
    ret_sub['ExRetVol_l0']=ret_sub['ExRetVol'].shift(0)
    ret_sub['ExRetVol_l1']=ret_sub['ExRetVol'].shift(1)
    ret_sub['ExRetVol_l2']=ret_sub['ExRetVol'].shift(2)
    ret_sub['ExRetVol_l3']=ret_sub['ExRetVol'].shift(3)
    ret_sub['ExRetVol_l4']=ret_sub['ExRetVol'].shift(4)
    ret_sub['ExRetVol_l5']=ret_sub['ExRetVol'].shift(5)
    ret_sub['ExRetVol_l6']=ret_sub['ExRetVol'].shift(6)
    ret_sub['ExRetVol_l7']=ret_sub['ExRetVol'].shift(7)
    ret_sub['ExRetVol_l8']=ret_sub['ExRetVol'].shift(8)
    ret_sub['ExRetVol_l9']=ret_sub['ExRetVol'].shift(9)
    ret_sub['ExRetVol_l10']=ret_sub['ExRetVol'].shift(10)
    ret_sub['ExRetVol_l11']=ret_sub['ExRetVol'].shift(11)
    ret_summary=pd.concat([ret_summary,ret_sub.iloc[12:]])#drop the first 12 variables in case of NaN
    
# =============================================================================
# run the pairs bootstrap regression
# =============================================================================

ret_summary=ret_summary.reset_index(drop='True')
size=len(ret_summary)
np.random.seed(10)

tLag_Pairs=np.empty((1000,12))
tCum_Pairs=np.empty((1000,12))

for n in range(0,1000):
    vera=np.floor(np.random.uniform(0,1,size)*size)
    resample=ret_summary.loc[vera,:]
    for i in range(0,12):
        regression=resample[['YM','ExRetVol_f1','ExRetVol_l'+str(i)]].dropna()
        form="ExRetVol_f1 ~ ExRetVol_l"+str(i)
        result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
        tLag_Pairs[n,i]=result.tvalues[1]
    print(n)

Table3_PanelAPairs=pd.DataFrame(columns=['Lag'],index=np.arange(1,13))

for i in range(1,13):
    Table3_PanelAPairs.loc[[i],['Lag']]=np.percentile(tLag_Pairs[:,i-1],97.5)

pd.DataFrame.to_csv(Table3_PanelAPairs,'Table3_PanelAPairs.csv')