import pandas as pd
import numpy as np
import statsmodels.formula.api as smf

# =============================================================================
# Objective: 
# generate the pairs bootstrap t-values for Table3 Panel B cases
# =============================================================================

# =============================================================================
# create the lagged volatiliaty scaled excess returns
# cumulative volatiliaty scaled excess returns
# =============================================================================

ret=pd.read_excel('Return.xlsx','Return')
ret=ret[ret['YM']>=198501]# make sure all returns are after 198501

ret['RF']=ret['Rf']+1#capital RF is the gross risk free rate
ret['Return']=ret['ExRet']+ret['RF']


ret_summary=pd.DataFrame()
for i in range(1,56):
    ret_sub=ret[ret['ID']==i]    
    #get the scaled excess return
    ret_sub['ExRetVol']=ret_sub['ExRet']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetVol_f1']=ret_sub['ExRetVol'].shift(-1)
    #get the cumulative excess return 
    ret_sub['ExRetCum1']=ret['ExRet']
    ret_sub['ExRetCum2']=((ret_sub['Return']*ret_sub['Return'].shift(1))-(ret_sub['RF']*ret_sub['RF'].shift(1)))/2
    ret_sub['ExRetCum3']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)))/3
    ret_sub['ExRetCum4']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)))/4
    ret_sub['ExRetCum5']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)))/5
    ret_sub['ExRetCum6']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4)*ret_sub['Return'].shift(5))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)*ret_sub['RF'].shift(5)))/6
    ret_sub['ExRetCum7']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4)*ret_sub['Return'].shift(5)*ret_sub['Return'].shift(6))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)*ret_sub['RF'].shift(5)*ret_sub['RF'].shift(6)))/7
    ret_sub['ExRetCum8']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4)*ret_sub['Return'].shift(5)*ret_sub['Return'].shift(6)*ret_sub['Return'].shift(7))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)*ret_sub['RF'].shift(5)*ret_sub['RF'].shift(6)*ret_sub['RF'].shift(7)))/8
    ret_sub['ExRetCum9']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4)*ret_sub['Return'].shift(5)*ret_sub['Return'].shift(6)*ret_sub['Return'].shift(7)*ret_sub['Return'].shift(8))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)*ret_sub['RF'].shift(5)*ret_sub['RF'].shift(6)*ret_sub['RF'].shift(7)*ret_sub['RF'].shift(8)))/9
    ret_sub['ExRetCum10']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4)*ret_sub['Return'].shift(5)*ret_sub['Return'].shift(6)*ret_sub['Return'].shift(7)*ret_sub['Return'].shift(8)*ret_sub['Return'].shift(9))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)*ret_sub['RF'].shift(5)*ret_sub['RF'].shift(6)*ret_sub['RF'].shift(7)*ret_sub['RF'].shift(8)*ret_sub['RF'].shift(9)))/10
    ret_sub['ExRetCum11']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4)*ret_sub['Return'].shift(5)*ret_sub['Return'].shift(6)*ret_sub['Return'].shift(7)*ret_sub['Return'].shift(8)*ret_sub['Return'].shift(9)*ret_sub['Return'].shift(10))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)*ret_sub['RF'].shift(5)*ret_sub['RF'].shift(6)*ret_sub['RF'].shift(7)*ret_sub['RF'].shift(8)*ret_sub['RF'].shift(9)*ret_sub['RF'].shift(10)))/11
    ret_sub['ExRetCum12']=((ret_sub['Return']*ret_sub['Return'].shift(1)*ret_sub['Return'].shift(2)*ret_sub['Return'].shift(3)*ret_sub['Return'].shift(4)*ret_sub['Return'].shift(5)*ret_sub['Return'].shift(6)*ret_sub['Return'].shift(7)*ret_sub['Return'].shift(8)*ret_sub['Return'].shift(9)*ret_sub['Return'].shift(10)*ret_sub['Return'].shift(11))-(ret_sub['RF']*ret_sub['RF'].shift(1)*ret_sub['RF'].shift(2)*ret_sub['RF'].shift(3)*ret_sub['RF'].shift(4)*ret_sub['RF'].shift(5)*ret_sub['RF'].shift(6)*ret_sub['RF'].shift(7)*ret_sub['RF'].shift(8)*ret_sub['RF'].shift(9)*ret_sub['RF'].shift(10)*ret_sub['RF'].shift(11)))/12
    ret_sub['ExRetCumVol1']=ret_sub['ExRetCum1']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol2']=ret_sub['ExRetCum2']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol3']=ret_sub['ExRetCum3']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol4']=ret_sub['ExRetCum4']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol5']=ret_sub['ExRetCum5']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol6']=ret_sub['ExRetCum6']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol7']=ret_sub['ExRetCum7']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol8']=ret_sub['ExRetCum8']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol9']=ret_sub['ExRetCum9']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol10']=ret_sub['ExRetCum10']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol11']=ret_sub['ExRetCum11']/ret_sub['Vol'].shift(1)
    ret_sub['ExRetCumVol12']=ret_sub['ExRetCum12']/ret_sub['Vol'].shift(1)

    ret_summary=pd.concat([ret_summary,ret_sub.iloc[12:]])#drop the first 12 variables in case of NaN
    
# =============================================================================
# run the pairs bootstrap regression
# =============================================================================

ret_summary=ret_summary.reset_index(drop='True')
size=len(ret_summary)
np.random.seed(10)

tLag_Pairs=np.empty((1000,12))
tCum_Pairs=np.empty((1000,12))

for n in range(0,1000):
    vera=np.floor(np.random.uniform(0,1,size)*size)
    resample=ret_summary.loc[vera,:]
    for i in range(0,12):
        regression=resample[['YM','ExRetVol_f1','ExRetCumVol'+str(i+1)]].dropna()
        form="ExRetVol_f1 ~ ExRetCumVol"+str(i+1)
        result=smf.ols(formula=form, data=regression).fit(cov_type='cluster',cov_kwds={'groups': regression['YM']},use_t=True)
        tCum_Pairs[n,i]=result.tvalues[1]
    print(n)

Table3_Pairs=pd.DataFrame(columns=['Cum'],index=np.arange(1,13))

for i in range(1,13):
    Table3_Pairs.loc[[i],['Cum']]=np.percentile(tCum_Pairs[:,i-1],97.5)

pd.DataFrame.to_csv(Table3_Pairs,'Table3_PanelBPairs.csv')